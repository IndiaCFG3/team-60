from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.fregister),
    path('login/',views.flogin),
    path('profile/',views.fprofile),
    path('xp1/',views.fxp1),
path('y/',views.ff),
path('x/',views.ft),
path('z/',views.fk),

]