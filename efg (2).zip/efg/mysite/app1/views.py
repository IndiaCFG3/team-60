from django.shortcuts import render
from .models import *
# Create your views here.
def fregister(request):
    return render(request,'register.html')

def flogin(request):
    return render(request,'login.html')

def fprofile(request):
    return render(request,'profile.html')

def ft(request):
    return render(request,'task.html')

def ff(request):
    return render(request,'feed.html')

def fk(request):
    return render(request,'lead.html')

def fxp1(request):
    x=mob_register()
    x.mob_name=request.POST.get('name')
    x.mob_email = request.POST.get('email')
    x.mob_pass = request.POST.get('pass')
    x.save()
    return render(request,'xp1.html')